#### `--option_name|-o`

option description

* Accept value: yes
* Is value required: yes
* Is multiple: yes
* Default: `array (  0 => 'Hello',  1 => 'world',)`
