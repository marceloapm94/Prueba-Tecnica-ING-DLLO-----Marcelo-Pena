#### `--option_name|-o`

option description

* Accept value: yes
* Is value required: no
* Is multiple: no
* Default: `INF`
