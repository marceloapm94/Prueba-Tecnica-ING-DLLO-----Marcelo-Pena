<?php
use PHPUnit\Framework\TestCase;

class NoTestCases extends TestCase
{
    public function noTestCase()
    {
    }
}
