<?php
// If process isolation fails to include this file, then
// PHPUnit_Framework_TestCase itself does not exist. :-)
require __DIR__ . '/../../../bootstrap.php';

const GITHUB_ISSUE = 797;
